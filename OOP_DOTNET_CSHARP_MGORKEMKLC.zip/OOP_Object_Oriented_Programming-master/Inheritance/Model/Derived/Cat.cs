﻿using Inheritance.Model.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance.Model.Derived
{
    public class Cat:Animals
    {
        public string Sounds { get; set; }
    }
}
